This distribution of the ZedGraph source code includes two versions:

Version 4.6.x is the .Net 1.1 compatible version
Version 5.1.x is the .Net 2.0 compatible version

You can refer to the following sites for more information:

Wiki            http://zedgraph.org
Sourceforge     http://sourceforge.net/projects/zedgraph/
CodeProject     http://www.codeproject.com/csharp/zedgraph.asp



